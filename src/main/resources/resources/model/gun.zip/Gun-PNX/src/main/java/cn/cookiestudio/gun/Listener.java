package cn.cookiestudio.gun;

public class Listener implements cn.nukkit.event.Listener {
//    @EventHandler
//    public void onDataPackReceive(DataPacketReceiveEvent event){
//       event.getPlayer().sendMessage("§b" + event.getPacket().toString());
//    }

//    @EventHandler
//    public void onPlayerMove(PlayerMoveEvent event){
//        Player player = event.getPlayer();
//        player.sendTitle("","§aPitch: " + player.getPitch() + ",Yaw: " + player.getYaw(),0,1,0);
//    }
}
